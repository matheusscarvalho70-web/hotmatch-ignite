import { useEffect, useRef, useState } from "react";
import { supabase, type DbChatMessage } from "@/lib/supabase";
import { useAppState } from "@/lib/hotmatch/store";
import { toast } from "sonner";

export type LocalMessage = {
  id: string;
  from: "me" | "them";
  kind: "text" | "audio" | "locked" | "gift" | "media";
  text?: string;
  media?: string;
  seconds?: number;
  price?: number;
  time: string;
};

function toLocal(msg: DbChatMessage, myId: string): LocalMessage {
  const from = msg.sender_id === myId ? "me" : "them";
  const time = new Date(msg.created_at).toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
  });

  const kind = (msg.message_kind ?? "text") as LocalMessage["kind"];

  return {
    id: msg.id,
    from,
    kind,
    text: msg.content ?? undefined,
    media: msg.media_url ?? undefined,
    seconds: msg.audio_seconds ?? undefined,
    price: msg.unlock_price && msg.unlock_price > 0 ? msg.unlock_price : undefined,
    time,
  };
}

export type UseChatOptions = {
  partnerId: string;
  partnerName?: string;
  isDemo?: boolean;
};

export function useChat({ partnerId, partnerName, isDemo }: UseChatOptions) {
  const { profileId } = useAppState();
  const storeMyId = profileId ?? "";
  const [partnerUuid, setPartnerUuid] = useState<string | null>(null);
  const [messages, setMessages] = useState<LocalMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  const myId = storeMyId || "7f56165e-1173-40df-bc95-d2cdb59a2399";

  useEffect(() => {
    if (!partnerId) {
      setPartnerUuid(null);
      return;
    }
    setPartnerUuid(partnerId);
  }, [partnerId]);

  useEffect(() => {
    if (!myId || !partnerUuid) {
      setLoading(false);
      return;
    }
    let cancelled = false;
    setLoading(true);

    (async () => {
      try {
        const { data, error } = await supabase
          .from("chat_messages")
          .select("*")
          .or(
            `and(sender_id.eq.${myId},receiver_id.eq.${partnerUuid}),and(sender_id.eq.${partnerUuid},receiver_id.eq.${myId})`,
          )
          .order("created_at", { ascending: true })
          .limit(100);

        if (!cancelled) {
          if (!error && data)
            setMessages(data.map((m) => toLocal(m as DbChatMessage, myId)));
          setLoading(false);
        }
      } catch {
        if (!cancelled) setLoading(false);
      }
    })();

    const channel = supabase
      .channel(`chat_${[myId, partnerUuid].sort().join("_")}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "chat_messages",
        },
        (payload) => {
          const msg = payload.new as DbChatMessage;
          const relevant =
            (msg.sender_id === myId && msg.receiver_id === partnerUuid) ||
            (msg.sender_id === partnerUuid && msg.receiver_id === myId);
          if (relevant && !cancelled) {
            setMessages((prev) => {
              if (prev.some((m) => m.id === msg.id)) return prev;
              return [...prev, toLocal(msg, myId)];
            });
          }
        },
      )
      .subscribe();

    channelRef.current = channel;

    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
      channelRef.current = null;
    };
  }, [myId, partnerUuid]);

  async function sendMessage(
    text: string,
    kind: "text" | "gift" | "audio" = "text",
  ): Promise<void> {
    if (!partnerUuid) {
      toast.error("Destinatário inválido.");
      return;
    }
    try {
      const insertPayload = {
        sender_id: myId,
        receiver_id: partnerUuid,
        content: text,
        message_kind: kind,
      };
      const { data, error } = await supabase
        .from("chat_messages")
        .insert(insertPayload)
        .select()
        .single();

      if (error) throw error;

      if (data) {
        const local = toLocal(data as DbChatMessage, myId);
        setMessages((prev) => {
          if (prev.some((m) => m.id === local.id)) return prev;
          return [...prev, local];
        });
      }

      notifyPartner(partnerUuid, "Nova mensagem!", text);
    } catch (err) {
      console.error("Erro ao enviar mensagem:", err);
    }
  }

  async function sendAudioMessage(
    mediaUrl: string,
    seconds: number,
  ): Promise<void> {
    if (!partnerUuid) return;
    try {
      const insertPayload = {
        sender_id: myId,
        receiver_id: partnerUuid,
        media_url: mediaUrl,
        audio_seconds: seconds,
        message_kind: "audio" as const,
        content: `Áudio (${seconds}s)`,
      };
      const { data, error } = await supabase
        .from("chat_messages")
        .insert(insertPayload)
        .select()
        .single();

      if (error) throw error;

      if (data) {
        const local = toLocal(data as DbChatMessage, myId);
        setMessages((prev) => {
          if (prev.some((m) => m.id === local.id)) return prev;
          return [...prev, local];
        });
      }

      notifyPartner(partnerUuid, "🎤 Áudio recebido", "Novo áudio para você");
    } catch (err: any) {
      console.error("Erro ao enviar áudio:", err);
    }
  }

  async function sendGiftMessage(
    emoji: string,
    name: string,
    price: number,
  ): Promise<void> {
    if (!partnerUuid) return;
    try {
      const insertPayload = {
        sender_id: myId,
        receiver_id: partnerUuid,
        content: `${emoji} ${name}`,
        message_kind: "gift" as const,
        unlock_price: price,
      };
      const { data, error } = await supabase
        .from("chat_messages")
        .insert(insertPayload)
        .select()
        .single();

      if (error) throw error;

      if (data) {
        const local = toLocal(data as DbChatMessage, myId);
        setMessages((prev) => {
          if (prev.some((m) => m.id === local.id)) return prev;
          return [...prev, local];
        });
      }

      notifyPartner(partnerUuid, `${emoji} Mimo recebido`, `Você ganhou: ${name}`);
    } catch (err) {
      console.error("Erro ao enviar mimo:", err);
    }
  }

  async function sendMediaMessage(
    mediaUrl: string,
    mediaType: "foto" | "vídeo",
  ): Promise<void> {
    if (!partnerUuid) return;
    try {
      const insertPayload = {
        sender_id: myId,
        receiver_id: partnerUuid,
        media_url: mediaUrl,
        message_kind: "media" as const,
        content: mediaType === "foto" ? "📷 Foto" : "🎬 Vídeo",
      };
      const { data, error } = await supabase
        .from("chat_messages")
        .insert(insertPayload)
        .select()
        .single();

      if (error) throw error;

      if (data) {
        const local = toLocal(data as DbChatMessage, myId);
        setMessages((prev) => {
          if (prev.some((m) => m.id === local.id)) return prev;
          return [...prev, local];
        });
      }

      notifyPartner(partnerUuid, "📷 Mídia recebida", "Nova mídia para você");
    } catch (err) {
      console.error("Erro ao enviar mídia:", err);
    }
  }

  return {
    messages,
    loading,
    sendMessage,
    sendAudioMessage,
    sendGiftMessage,
    sendMediaMessage,
    myId,
    partnerName,
    isDemo,
  };
}

async function notifyPartner(
  receiverId: string,
  title: string,
  body: string,
) {
  try {
    const { data } = await supabase
      .from("profiles")
      .select("onesignal_player_id")
      .eq("id", receiverId)
      .maybeSingle();
    if (!data?.onesignal_player_id) return;
    await supabase.functions.invoke("notify-user", {
      body: {
        player_id: data.onesignal_player_id,
        title,
        message: body,
      },
    });
  } catch (e) {
    console.warn("[Push] notifyPartner failed:", e);
  }
                    }
    
