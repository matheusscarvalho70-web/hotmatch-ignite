import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

if (!supabaseUrl || !supabaseAnonKey) {
  const missing = [
    !supabaseUrl && "VITE_SUPABASE_URL",
    !supabaseAnonKey && "VITE_SUPABASE_ANON_KEY",
  ].filter(Boolean).join(", ");
  throw new Error(
    `[supabase] Missing env var(s): ${missing}. ` +
    "On Vercel, add these in Project Settings → Environment Variables. " +
    "They must be present at BUILD time (Vite inlines import.meta.env)."
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export type DbProfile = {
  id: string;
  gender: "male" | "female";
  name: string;
  age: number;
  bio: string | null;
  location: string | null;
  avatar_url: string | null;
  xp: number;
  level: string;
  coin_balance: number;
  earnings_brl: number;
  is_verified: boolean;
  is_demo: boolean;
  onesignal_player_id: string | null;
  latitude: number | null;
  longitude: number | null;
  public_photos: string[] | null;
  vip_photos: string[] | null;
  gallery_price: number;
  is_vip: boolean;
  vip_expires_at: string | null;
  created_at: string;
};

export type DbUserPhoto = {
  id: string;
  user_id: string;
  photo_url: string;
  is_vip: boolean;
  coin_price: number;
  sort_order: number;
  created_at: string;
};

export type DbNotification = {
  id: string;
  user_id: string;
  type: "message" | "match" | "like" | "feed" | "welcome";
  title: string;
  content: string | null;
  is_read: boolean;
  actor_id: string | null;
  actor_avatar_url: string | null;
  created_at: string;
};

export type DbChatMessage = {
  id: string;
  sender_id: string | null;
  receiver_id: string | null;
  content: string | null;
  media_url: string | null;
  is_locked: boolean;
  unlock_price: number;
  message_kind: "text" | "audio" | "locked" | "gift" | "media";
  audio_seconds: number | null;
  created_at: string;
};

export type DbReport = {
  id: string;
  reporter_id: string | null;
  reported_user_id: string | null;
  subject: string;
  description: string | null;
  status: "pending" | "reviewed" | "resolved";
  created_at: string;
};

export type DbFeedPost = {
  id: string;
  author_id: string;
  caption: string | null;
  media_url: string;
  media_type: "foto" | "vídeo";
  is_locked: boolean;
  coin_price: number;
  likes: number;
  created_at: string;
  profiles?: DbProfile;
};

export type DbMatch = {
  id: string;
  user_id: string;
  target_user_id: string;
  action: "like" | "pass";
  created_at: string;
};

export type DbLike = {
  id: string;
  user_id: string;
  target_user_id: string;
  created_at: string;
};

export type DbMutualMatch = {
  id: string;
  user1_id: string;
  user2_id: string;
  created_at: string;
};

export type DbTransaction = {
  id: string;
  user_id: string;
  /** BRL monetary value (purchases, withdrawals). Zero for coin-only operations. */
  amount: number;
  /** Coin delta — positive for credits, negative for debits. */
  coins_amount: number;
  type: "purchase" | "gift_sent" | "gift_received" | "unlock" | "withdrawal" | "vip_subscription" | string;
  status: "pending" | "approved" | "cancelled" | "failed";
  provider: string | null;
  provider_payment_id: string | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
};
