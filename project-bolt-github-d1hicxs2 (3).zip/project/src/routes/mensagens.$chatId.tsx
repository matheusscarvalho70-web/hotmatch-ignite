import { createFileRoute, Link, useParams, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  Ban,
  Coins,
  Flag,
  Gift,
  ImagePlus,
  Mic,
  MoreVertical,
  PhoneOff,
  Play,
  Pause,
  Send,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { gifts } from "@/lib/hotmatch/data";
import { actions, useAppState } from "@/lib/hotmatch/store";
import { useChat, type LocalMessage } from "@/hooks/use-chat";
import { useProfiles } from "@/hooks/use-profiles";
import { supabase } from "@/lib/supabase";
import { Lightbox } from "@/components/hotmatch/Lightbox";

export const Route = createFileRoute("/mensagens/$chatId")({
  head: () => ({
    meta: [
      { title: "Conversa — HotMatch" },
      { name: "description", content: "Chat em tempo real, áudios, presentes e chamadas." },
    ],
  }),
  component: Chat,
});

function Chat() {
  const { chatId } = useParams({ from: "/mensagens/$chatId" });
  const navigate = useNavigate();
  const { profileId, gender, coins } = useAppState();
  const isCreator = gender === "female";
  const myId = profileId ?? "";
  const partnerId = chatId;

  const { profiles: dbProfiles } = useProfiles();
  const dbPartner = dbProfiles.find((p) => p.id === partnerId);
  const partnerName = dbPartner?.name ?? "Conversa";
  const partnerAvatar = dbPartner?.avatar_url ?? null;

  const [hasMutualMatch, setHasMutualMatch] = useState<boolean | null>(null);

  useEffect(() => {
    if (!myId || !partnerId) return;
    if (dbPartner === undefined) return;
    if (dbPartner?.is_demo) {
      setHasMutualMatch(true);
      return;
    }
    let cancelled = false;
    const [u1, u2] = [myId, partnerId].sort();
    supabase
      .from("mutual_matches")
      .select("id")
      .eq("user_1", u1)
      .eq("user_2", u2)
      .maybeSingle()
      .then(async ({ data }) => {
        if (cancelled) return;
        if (data) {
          setHasMutualMatch(true);
        } else {
          const { data: myLike } = await supabase
            .from("matches")
            .select("id")
            .eq("user_id", myId)
            .eq("target_user_id", partnerId)
            .eq("action", "like")
            .maybeSingle();
          if (cancelled) return;
          if (myLike) {
            const { data: partnerLike } = await supabase
              .from("matches")
              .select("id")
              .eq("user_id", partnerId)
              .eq("target_user_id", myId)
              .eq("action", "like")
              .maybeSingle();
            if (cancelled) return;
            setHasMutualMatch(!!partnerLike);
          } else {
            setHasMutualMatch(false);
          }
        }
      });
    return () => {
      cancelled = true;
    };
  }, [myId, partnerId, dbPartner]);

  const { messages, sendMessage, sendAudioMessage, sendGiftMessage, sendMediaMessage } = useChat({
    partnerId,
    partnerName,
    isDemo: dbPartner?.is_demo,
  });

  const [inputText, setInputText] = useState("");
  const [showGiftModal, setShowGiftModal] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  const [isRecording, setIsRecording] = useState(false);
  const [audioTimer, setAudioTimer] = useState(0);
  const audioIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioSecondsRef = useRef(0);

  const [callState, setCallState] = useState<"idle" | "voice" | "video">("idle");
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const callStreamRef = useRef<MediaStream | null>(null);
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = () => {
    if (!inputText.trim()) return;
    sendMessage(inputText, "text");
    setInputText("");
  };

  const handleSendGift = (gift: (typeof gifts)[0]) => {
    setShowGiftModal(false);
    if (coins < gift.price) {
      toast.error(`Saldo insuficiente. Você precisa de ${gift.price} moedas.`);
      return;
    }
    sendGiftMessage(gift.emoji, gift.name, gift.price);
    actions.spendCoins(gift.price);
    toast.success(`Você enviou ${gift.name}!`);
  };

  const handleMediaSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const isVideo = file.type.startsWith("video/");
    const isImage = file.type.startsWith("image/");
    if (!isVideo && !isImage) {
      toast.error("Selecione uma imagem ou vídeo.");
      return;
    }
    toast.loading("Enviando mídia...", { id: "media-upload" });
    try {
      const ext = file.name.split(".").pop() || (isVideo ? "mp4" : "jpg");
      const fileName = `media_${Date.now()}.${ext}`;
      const folder = isVideo ? "chat-video" : "chat-photo";
      const { error: uploadError } = await supabase.storage
        .from("chat-media")
        .upload(`${folder}/${fileName}`, file, { contentType: file.type });
      if (uploadError) throw uploadError;
      const { data: urlData } = supabase.storage
        .from("chat-media")
        .getPublicUrl(`${folder}/${fileName}`);
      await sendMediaMessage(urlData.publicUrl, isVideo ? "vídeo" : "foto");
      toast.success("Mídia enviada!", { id: "media-upload" });
    } catch (err) {
      toast.error("Erro ao enviar mídia.", { id: "media-upload" });
      console.error(err);
    } finally {
      e.target.value = "";
    }
  };

  const startAudioRecord = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = MediaRecorder.isTypeSupported("audio/webm")
        ? "audio/webm"
        : MediaRecorder.isTypeSupported("audio/mp4")
          ? "audio/mp4"
          : "";
      const recorder = mimeType
        ? new MediaRecorder(stream, { mimeType })
        : new MediaRecorder(stream);
      const ext = mimeType.includes("mp4") ? "mp4" : "webm";
      audioChunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };
      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blobType = mimeType || "audio/webm";
        const blob = new Blob(audioChunksRef.current, { type: blobType });
        const seconds = audioSecondsRef.current;
        if (blob.size > 0 && seconds > 0) {
          toast.loading("Enviando áudio...", { id: "audio-upload" });
          try {
            const fileName = `audio_${Date.now()}.${ext}`;
            const { error: uploadError } = await supabase.storage
              .from("chat-media")
              .upload(`chat-audio/${fileName}`, blob, { contentType: blobType });
            if (uploadError) throw uploadError;
            const { data: urlData } = supabase.storage
              .from("chat-media")
              .getPublicUrl(`chat-audio/${fileName}`);
            await sendAudioMessage(urlData.publicUrl, seconds);
            toast.success("Áudio enviado!", { id: "audio-upload" });
          } catch (err) {
            toast.error("Erro ao enviar áudio.", { id: "audio-upload" });
            console.error(err);
          }
        }
      };
      recorder.start();
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
      setAudioTimer(0);
      audioSecondsRef.current = 0;
      audioIntervalRef.current = setInterval(() => {
        audioSecondsRef.current += 1;
        setAudioTimer(audioSecondsRef.current);
      }, 1000);
    } catch (err) {
      toast.error("Não foi possível acessar o microfone.");
      console.error(err);
    }
  };

  const stopAudioRecord = () => {
    if (audioIntervalRef.current) clearInterval(audioIntervalRef.current);
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
    }
    setIsRecording(false);
    setAudioTimer(0);
  };

  const handleBlock = () => {
    setShowMenu(false);
    toast.success(`${partnerName} foi bloqueado.`);
  };

  const handleReportSubmit = async (subject: string, description: string) => {
    if (!subject.trim()) {
      toast.error("Por favor, preencha o assunto.");
      return;
    }
    try {
      const { error } = await supabase.from("reports").insert({
        reporter_id: myId || null,
        reported_user_id: partnerId || null,
        subject: subject.trim(),
        description: description.trim() || null,
      });
      if (error) throw error;
      toast.success("Denúncia enviada.");
      setShowReport(false);
    } catch (err) {
      toast.error("Erro ao enviar denúncia.");
      console.error(err);
    }
  };

  const startCall = async (type: "voice" | "video") => {
    try {
      const constraints = type === "video" ? { audio: true, video: true } : { audio: true };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      callStreamRef.current = stream;
      setCallState(type);
    } catch {
      toast.error("Não foi possível acessar o microfone/câmera.");
    }
  };

  /* After CallOverlay mounts (callState !== "idle"), attach the stream to
     the local <video> element. The ref is null until the overlay renders. */
  useEffect(() => {
    if (callState === "idle" || !callStreamRef.current) return;
    if (callState === "video" && localVideoRef.current) {
      localVideoRef.current.srcObject = callStreamRef.current;
      localVideoRef.current.play().catch(() => {});
    }
  }, [callState]);

  const endCall = () => {
    callStreamRef.current?.getTracks().forEach((t) => t.stop());
    callStreamRef.current = null;
    setCallState("idle");
  };

  useEffect(() => {
    return () => {
      if (audioIntervalRef.current) clearInterval(audioIntervalRef.current);
      callStreamRef.current?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  return (
    <div className="flex flex-col h-[100dvh] bg-[#0B0B0E] text-white">
      <div className="flex items-center justify-between px-4 py-3 bg-[#121218]/80 backdrop-blur-md border-b border-white/10 sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <Link to="/mensagens" className="text-white/70 hover:text-white">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <button
            onClick={() => navigate({ to: "/perfil", search: { uid: partnerId, from: chatId } })}
            className="flex items-center gap-3"
          >
            <div className="relative">
              <img
                src={partnerAvatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400"}
                alt={partnerName}
                className="w-10 h-10 rounded-full object-cover border border-[#FFD700]/30"
              />
              <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-[#0B0B0E]" />
            </div>
            <div className="text-left">
              <h2 className="font-semibold text-sm leading-tight text-white flex items-center gap-1">
                {partnerName}
              </h2>
              <span className="text-[10px] text-green-400 font-medium">Online agora</span>
            </div>
          </button>
        </div>

        <div className="flex items-center gap-3 text-white/80">
          <button onClick={() => setShowGiftModal(true)} className="p-2 hover:bg-white/5 rounded-full transition">
            <Gift className="w-5 h-5 text-[#FFD700]" />
          </button>
          <div className="relative">
            <button onClick={() => setShowMenu((v) => !v)} className="p-2 hover:bg-white/5 rounded-full transition">
              <MoreVertical className="w-5 h-5" />
            </button>
            {showMenu && (
              <>
                <div className="fixed inset-0 z-30" onClick={() => setShowMenu(false)} />
                <div className="absolute right-0 top-full mt-1 z-40 w-44 overflow-hidden rounded-2xl border border-white/10 bg-[#1C1C24] shadow-2xl">
                  <button
                    onClick={handleBlock}
                    className="flex w-full items-center gap-3 px-4 py-3 text-sm font-medium text-white hover:bg-white/5 transition"
                  >
                    <Ban className="w-4 h-4 text-red-400" /> Bloquear
                  </button>
                  <button
                    onClick={() => {
                      setShowMenu(false);
                      setShowReport(true);
                    }}
                    className="flex w-full items-center gap-3 px-4 py-3 text-sm font-medium text-white hover:bg-white/5 transition border-t border-white/5"
                  >
                    <Flag className="w-4 h-4 text-orange-400" /> Denunciar
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <div className="text-center my-2">
          <span className="text-[10px] bg-white/5 text-white/50 px-3 py-1 rounded-full uppercase tracking-wider border border-white/5">
            Conexão segura HotMatch
          </span>
        </div>
        {messages.map((msg) => (
          <MessageBubble key={msg.id} msg={msg} onImageClick={setLightboxImage} />
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-3 bg-[#121218] border-t border-white/10 sticky bottom-0 z-20">
        {isRecording ? (
          <div className="flex items-center justify-between bg-[#1C1C24] px-4 py-3 rounded-full border border-red-500/50">
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
              <span className="text-sm font-medium text-red-400">
                Gravando áudio... {Math.floor(audioTimer / 60)}:{audioTimer % 60 < 10 ? `0${audioTimer % 60}` : audioTimer % 60}
              </span>
            </div>
            <button
              onClick={stopAudioRecord}
              className="bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-black px-4 py-1.5 rounded-full text-xs font-bold"
            >
              Enviar
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <button onClick={() => fileInputRef.current?.click()} className="p-2.5 text-[#FFD700] hover:bg-white/5 rounded-full transition">
              <ImagePlus className="w-5 h-5" />
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,video/*"
              onChange={handleMediaSelect}
              className="hidden"
            />
            <button onClick={startAudioRecord} className="p-2.5 text-white/70 hover:text-white hover:bg-white/5 rounded-full transition">
              <Mic className="w-5 h-5" />
            </button>
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              placeholder="Digite sua mensagem..."
              className="flex-1 bg-[#1C1C24] text-white placeholder-white/40 text-sm px-4 py-2.5 rounded-full border border-white/10 focus:outline-none focus:border-[#FFD700]"
            />
            <button
              onClick={handleSend}
              className="p-2.5 bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-black rounded-full hover:opacity-90 transition shadow-md shadow-[#FFD700]/20"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>

      {showGiftModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-end justify-center" onClick={() => setShowGiftModal(false)}>
          <div className="bg-[#121218] w-full max-w-lg rounded-t-3xl p-6 border-t border-white/10 space-y-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold flex items-center gap-2 text-[#FFD700]">
                <Gift className="w-5 h-5" /> Enviar Presente
              </h3>
              <button onClick={() => setShowGiftModal(false)} className="text-white/50 hover:text-white">
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {gifts.map((g) => (
                <button
                  key={g.id}
                  onClick={() => handleSendGift(g)}
                  className="group relative bg-[#1C1C24] hover:border-[#FFD700] border border-white/5 p-4 rounded-2xl flex flex-col items-center gap-2 transition hover:scale-105"
                >
                  <span className="grid size-14 place-items-center rounded-full text-3xl" style={{ backgroundColor: `${g.color}22` }}>
                    {g.emoji}
                  </span>
                  <span className="text-xs font-semibold text-white">{g.name}</span>
                  <span className="text-[10px] text-[#FFD700] font-bold flex items-center gap-1">
                    <Coins className="w-3 h-3" /> {g.price}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {showReport && (
        <ReportModal partnerName={partnerName} onClose={() => setShowReport(false)} onSubmit={handleReportSubmit} />
      )}

      {callState !== "idle" && (
        <CallOverlay
          type={callState}
          partnerName={partnerName}
          partnerAvatar={partnerAvatar}
          onEnd={endCall}
          localVideoRef={localVideoRef}
        />
      )}

      {lightboxImage && (
        <Lightbox src={lightboxImage} onClose={() => setLightboxImage(null)} />
      )}
    </div>
  );
}

function MessageBubble({ msg, onImageClick }: { msg: LocalMessage; onImageClick?: (url: string) => void }) {
  const isMe = msg.from === "me";
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);

  const togglePlay = () => {
    const el = audioRef.current;
    if (!el) return;
    if (playing) {
      el.pause();
      setPlaying(false);
    } else {
      el.play();
      setPlaying(true);
    }
  };

  useEffect(() => {
    const el = audioRef.current;
    if (!el) return;
    const onTimeUpdate = () => {
      if (el.duration > 0) {
        setProgress((el.currentTime / el.duration) * 100);
      }
    };
    const onEnded = () => {
      setPlaying(false);
      setProgress(0);
    };
    el.addEventListener("timeupdate", onTimeUpdate);
    el.addEventListener("ended", onEnded);
    return () => {
      el.removeEventListener("timeupdate", onTimeUpdate);
      el.removeEventListener("ended", onEnded);
    };
  }, []);

  return (
    <div className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm ${
          isMe
            ? "bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-black font-medium"
            : "bg-[#1C1C24] text-white border border-white/5"
        }`}
      >
        {msg.kind === "audio" && msg.media ? (
          <div className="flex items-center gap-3 min-w-[160px]">
            <button
              onClick={togglePlay}
              className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
                isMe ? "bg-black text-[#FFD700]" : "bg-[#FFD700] text-black"
              }`}
            >
              {playing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
            </button>
            <div className="flex flex-col flex-1">
              <div className="flex items-center justify-between text-[10px] opacity-70 mb-1">
                <span>Áudio</span>
                <span>{msg.seconds ? `${msg.seconds}s` : ""}</span>
              </div>
              <div className={`h-1.5 rounded-full w-full ${isMe ? "bg-black/20" : "bg-white/20"}`}>
                <div
                  className={`h-full rounded-full transition-[width] duration-150 ease-linear ${isMe ? "bg-black" : "bg-[#FFD700]"}`}
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
            <audio ref={audioRef} src={msg.media} preload="none" />
          </div>
        ) : msg.kind === "gift" ? (
          <div className="space-y-1 text-center py-1">
            <div className="text-3xl">{msg.text?.split(" ")[0]}</div>
            <div className="font-bold text-xs">{msg.text}</div>
            <div className="text-[10px] opacity-70">Presente enviado</div>
          </div>
        ) : msg.kind === "media" && msg.media ? (
          <div className="space-y-1">
            {msg.media.match(/\.(mp4|webm|mov|m4v)$/i) ? (
              <video src={msg.media} controls className="rounded-xl max-w-[220px] max-h-[300px]" />
            ) : (
              <img
                src={msg.media}
                alt="Mídia"
                onClick={() => onImageClick?.(msg.media!)}
                className="rounded-xl max-w-[220px] max-h-[300px] object-cover cursor-pointer"
              />
            )}
          </div>
        ) : (
          <p className="break-words leading-relaxed">{msg.text}</p>
        )}
        <div className={`text-[9px] mt-1 text-right ${isMe ? "text-black/60" : "text-white/40"}`}>
          {msg.time}
        </div>
      </div>
    </div>
  );
}

function ReportModal({
  partnerName,
  onClose,
  onSubmit,
}: {
  partnerName: string;
  onClose: () => void;
  onSubmit: (subject: string, description: string) => void;
}) {
  const [subject, setSubject] = useState("");
  const [description, setDescription] = useState("");

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-[#121218] border border-white/10 w-full max-w-sm rounded-3xl p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <Flag className="w-5 h-5 text-orange-400" /> Denunciar {partnerName}
          </h3>
          <button onClick={onClose} className="text-white/50 hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>
        <div className="space-y-3">
          <div>
            <label className="text-xs font-semibold text-white/60 block mb-1.5">Assunto</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Ex: Comportamento inadequado"
              className="w-full bg-[#1C1C24] text-white placeholder-white/40 text-sm px-4 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-[#FFD700]"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-white/60 block mb-1.5">Descrição (opcional)</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Descreva o ocorrido..."
              rows={3}
              className="w-full bg-[#1C1C24] text-white placeholder-white/40 text-sm px-4 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-[#FFD700] resize-none"
            />
          </div>
        </div>
        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-full border border-white/10 text-white/60 text-sm font-medium hover:bg-white/5 transition"
          >
            Cancelar
          </button>
          <button
            onClick={() => onSubmit(subject, description)}
            className="flex-[1.4] py-2.5 rounded-full bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-black text-sm font-bold"
          >
            Enviar Denúncia
          </button>
        </div>
      </div>
    </div>
  );
}

function CallOverlay({
  type,
  partnerName,
  partnerAvatar,
  onEnd,
  localVideoRef,
}: {
  type: "voice" | "video";
  partnerName: string;
  partnerAvatar: string | null;
  onEnd: () => void;
  localVideoRef: React.RefObject<HTMLVideoElement | null>;
}) {
  const [callDuration, setCallDuration] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    timerRef.current = setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec < 10 ? `0${sec}` : sec}`;
  };

  return (
    <div className="fixed inset-0 z-[60] bg-[#0B0B0E] flex flex-col items-center justify-between py-12 px-6">
      <div className="flex flex-col items-center gap-3 mt-8">
        <div className="relative">
          <img
            src={partnerAvatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400"}
            alt={partnerName}
            className={`rounded-full object-cover border-2 border-[#FFD700]/40 ${type === "video" ? "w-28 h-28" : "w-32 h-32"}`}
          />
          {type === "voice" && (
            <div className="absolute inset-0 rounded-full border-2 border-[#FFD700]/20 animate-ping" />
          )}
        </div>
        <h2 className="text-xl font-bold text-white mt-2">{partnerName}</h2>
        <p className="text-sm text-green-400 font-medium">
          {type === "video" ? "Chamada de vídeo" : "Chamada de voz"} · {formatTime(callDuration)}
        </p>
      </div>

      {type === "video" && (
        <div className="absolute bottom-32 right-6 w-32 h-44 rounded-2xl overflow-hidden border-2 border-white/20 bg-black shadow-2xl">
          <video
            ref={localVideoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover scale-x-[-1]"
          />
        </div>
      )}

      <div className="flex items-center gap-6">
        <button
          onClick={onEnd}
          className="w-16 h-16 rounded-full bg-red-500 hover:bg-red-600 flex items-center justify-center transition shadow-lg shadow-red-500/30"
        >
          <PhoneOff className="w-7 h-7 text-white" />
        </button>
      </div>
    </div>
  );
}
